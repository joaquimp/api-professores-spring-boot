package br.mackenzie.ps2.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiProfessoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiProfessoresApplication.class, args);
	}

}
